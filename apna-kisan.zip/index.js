const express = require('express');
const cookieParser = require("cookie-parser");
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();
const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ limit: '1mb', extended: true }));
app.use(cookieParser());
const port = 3000;

// Middleware to parse JSON
app.use(express.json());

// GET route for root
app.get('/api/', (req, res) => {
  res.status(200).json({message: 'Hello, Node.js API!'});
});

// Another sample GET route
app.get('/api/hellog', (req, res) => {
  res.status(200).json({ message: 'Hello from your API!' });
});

// Sample POST route
app.post('/api/data', (req, res) => {
  const data = req.body;
  res.json({ received: data });
});
const authRouter = require('./routes/authRouter');
const productRouter = require('./routes/productRoute');
const notificationRoute = require('./routes/notificationRoute');
const inventoryRoute = require('./routes/inventoryRoute');
const translateRoute = require('./routes/translateRoute');
// Routes 
app.use('/auth', authRouter);
app.use('/product', productRouter);
app.use('/notifications', notificationRoute);
app.use('/inventory', inventoryRoute);
app.use('/translate', translateRoute);

// Start the server
app.listen(port, () => {
  console.log(`API running at http://localhost:${port}`);
});
