import { handleUserRegister } from '../../controllers/authController';

export default function handler(req, res) {
  if (req.method === 'POST') {
    return handleUserRegister(req, res);
  }

  res.setHeader('Allow', ['POST']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
